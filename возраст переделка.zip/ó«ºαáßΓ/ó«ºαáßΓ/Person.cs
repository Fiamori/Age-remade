﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GH_
{
    internal class Person
    {
        public string Name { get; }
        public string Surname { get; }
        public DateTime DateOfBirth { get; }

        public Person(string name, string surname, DateTime dateOfBirth)
        {
            Name = name;
            Surname = surname;
            DateOfBirth = dateOfBirth;
        }

        public int GetAge()
        {
            DateTime now = DateTime.Today;
            int age = now.Year - DateOfBirth.Year;

            if (now < DateOfBirth.AddYears(age))
            {
                age--;
            }

            return age;
        }
    }
}
