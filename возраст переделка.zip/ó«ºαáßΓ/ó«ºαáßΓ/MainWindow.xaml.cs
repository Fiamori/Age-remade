﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GH_
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateAge_Click(object sender, RoutedEventArgs e)
        {

            if (txtName.Text != "" && txtSurname.Text != "" && dpDateOfBirth.SelectedDate.HasValue)
            {
                Person newEmployee = new Person(txtName.Text, txtSurname.Text, dpDateOfBirth.SelectedDate.Value);
                txtAge.Text = $"{txtName.Text} {txtSurname.Text}, возраст: {newEmployee.GetAge()}";

                int age = newEmployee.GetAge();

                if (age < 18)
                    txtAge1.Text = $"Фу, вы младше 18(";

                if (age < 1)
                    MessageBox.Show("Вы родились в этом году, зачем вам узнавать возраст? Как вы вообще пишете?! Вы Иисус?");

            }

            string username = txtName.Text;
            string password = txtSurname.Text;

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Пожалуйста, заполните имя.");
                return;
            }

            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните фамилию.");
                return;
            }
        }
    }
}

